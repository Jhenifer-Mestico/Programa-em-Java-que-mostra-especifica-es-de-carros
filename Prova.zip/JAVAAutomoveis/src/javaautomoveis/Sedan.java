package javaautomoveis;

public class Sedan extends JAVAAutomoveis{
    
    double precoSedan;
    
    public double aumentoAnual(double valor){
        
        if(valor <= 5000){
            precoSedan = (valor * 0.02) + valor;
        }
        
        else if(valor >= 5000.01 || valor <= 15000){
            precoSedan = (valor * 0.05) + valor;
        }
        
        else if(valor >= 15000.01 || valor <= 25000){
            precoSedan = (valor *0.15) + valor;
        }
        
        else if (valor > 25000){
            precoSedan = valor - (valor * 0.10);
        }
        
        return precoSedan;
    }
     
}