package javaautomoveis;

public class JAVAAutomoveis {

    private String modelo, marca;
    private int ano, quantPortas;
    private double valor;

    public JAVAAutomoveis() {
    }

    public JAVAAutomoveis(String modelo, String marca, int ano, int quantPortas, double valor) {
        this.modelo = modelo;
        this.marca = marca;
        this.ano = ano;
        this.quantPortas = quantPortas;
        this.valor = valor;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public int getQuantPortas() {
        return quantPortas;
    }

    public void setQuantPortas(int quantPortas) {
        this.quantPortas = quantPortas;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    @Override
    public String toString() {
        return "\nAutomóveis:\n\n" + "Modelo:" + modelo + "\nMarca:" + marca + "\nAno:" + ano + "\nQuantidade de Portas:" + quantPortas + "\nValor:R$" + valor;
    }
    
}