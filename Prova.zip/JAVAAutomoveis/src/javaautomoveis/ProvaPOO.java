package javaautomoveis;

public class ProvaPOO {
   
    public static void main(String[] args) {
   
      SUV  objsuv = new SUV();
      Sedan objsedan = new Sedan();
      JAVAAutomoveis autSedan = new JAVAAutomoveis();
      
      autSedan.setAno(1998);
      autSedan.setMarca("FIAT");
      autSedan.setModelo("UNO");
      autSedan.setQuantPortas(4);
      autSedan.setValor(30400.55);
      
      JAVAAutomoveis autSUV = new JAVAAutomoveis();
      
      autSUV.setAno(2000);
      autSUV.setMarca("SUV");
      autSUV.setModelo("GOL");
      autSUV.setQuantPortas(2);
      autSUV.setValor(20000.75);
      
      String resultSedan = String.format("%.2f", objsedan.aumentoAnual(autSedan.getValor()));
      
        System.out.println(autSedan.toString() + "\nO valor do UNO com o aumento anual será: R$" + resultSedan);
        
        String resultSUV = String.format("%.2f", objsuv.desconto(autSUV.getValor(), 20));
        
        System.out.println(autSUV.toString() + "\nO valor do SUV com desconto será: R$" + resultSUV);
    }
}