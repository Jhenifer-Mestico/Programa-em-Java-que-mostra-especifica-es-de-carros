package javaautomoveis;

public class SUV extends JAVAAutomoveis{

    double valor2;
    public SUV(){
        
    }
    
    public double desconto(double valor, double desconto){
    
        valor2 = valor - ((desconto * valor) / 100);
        return valor2;
}
    
   }